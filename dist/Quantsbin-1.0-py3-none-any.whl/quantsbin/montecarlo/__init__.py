"""
    developed by Quantsbin - Jun'18

"""

