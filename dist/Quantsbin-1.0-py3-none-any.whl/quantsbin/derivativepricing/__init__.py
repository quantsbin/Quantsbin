"""
    developed by Quantsbin - Jun'18

"""

from .instruments import EqOption, FutOption, FXOption, ComOption
from .optionstrategies import OptionStr1Udl, StdStrategies
from .plotting import Plotting